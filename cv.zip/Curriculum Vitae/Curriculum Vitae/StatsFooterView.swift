//
//  StatsFooterView.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 23/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

class StatsFooterView : UITableViewCell {
	@IBOutlet var left : UILabel!
	@IBOutlet var right : UILabel!
}

@IBDesignable class StatsGradient : UIView {

	override func draw(_ rect: CGRect) {

		let context = UIGraphicsGetCurrentContext()!

		let colors = [#colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1), #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1), #colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1)].map { $0.cgColor } as CFArray

		let gradient = CGGradient(colorsSpace: nil, colors: colors, locations: [0, 0.5, 1])!

		let bandRect = CGRect(x: 0, y: 0, width: rect.width, height: 12)
		let bandPath = UIBezierPath(roundedRect: bandRect, cornerRadius: 6)
		context.saveGState()
		bandPath.addClip()
		context.drawLinearGradient(gradient,
		                           start: CGPoint(x: bandRect.minX, y: bandRect.midY),
		                           end: CGPoint(x: bandRect.maxX, y: bandRect.midY),
		                           options: [])
		context.restoreGState()
	}
}

//
//  UITableViewCell+RemoveSeparator.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 24/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

extension UITableViewCell {
	var hideSeparator : Bool {
		set {
			if newValue {
				separatorInset = UIEdgeInsets(top: 0, left: 1000, bottom: 0, right: 0)
			} else {
				separatorInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
			}
		}
		get {
			return separatorInset == UIEdgeInsets(top: 0, left: 1000, bottom: 0, right: 0)
		}
	}
}

//
//  ViewController+MailCompose.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 26/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit
import MessageUI

extension ViewController : MFMailComposeViewControllerDelegate {

	func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {

		controller.dismiss(animated: true, completion: nil)

		if result == .sent {

			let thankYouAlert = UIAlertController(title: "Thank you!", message: "I'll reply to it as soon as possible!", preferredStyle: .alert)

			thankYouAlert.addAction(UIAlertAction(title: "Dismiss", style: .default) { action in
				thankYouAlert.dismiss(animated: true, completion: nil)
			})

			present(thankYouAlert, animated: true, completion: nil)

			Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { timer in
				thankYouAlert.dismiss(animated: true, completion: nil)
			}
		}
	}
}

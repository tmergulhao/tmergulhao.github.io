//
//  LinkCell.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 26/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

enum LinkType : String {
	case link, telephone, mail
}

class LinkCell : UITableViewCell {

	@IBOutlet var label : UILabel!
	@IBOutlet var typeImage : UIImageView!

	var url : URL!

	var type : LinkType! {
		didSet {
			switch type! {
			case .link: typeImage.image = StyleKit.imageOfSafari
			case .telephone: typeImage.image = StyleKit.imageOfTelephone
			case .mail: typeImage.image = StyleKit.imageOfMail
			}
		}
	}
}

//
//  StatCellView.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 23/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

class StatCellView : UITableViewCell {

	@IBOutlet var knobs : StatCellKnobs!
	@IBOutlet var label : UILabel!

//	@IBOutlet var knobs : Array<StatCellKnob>!
}

@IBDesignable class StatCellKnobs : UIView {

	@IBInspectable var first : CGFloat = 0 { didSet { setNeedsDisplay() } }
	@IBInspectable var second : CGFloat = 0 { didSet { setNeedsDisplay() } }
	@IBInspectable var third : CGFloat = 0 { didSet { setNeedsDisplay() } }

	func interpolateColor (from value : CGFloat) -> UIColor {

		if value == 1 { return #colorLiteral(red: 0.1843137255, green: 0.6509803922, blue: 0.9176470588, alpha: 1) }

		var hue : CGFloat!

		if value < 0.5 {
			hue = (#colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1).hue - #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1).hue) * value * 2 + #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1).hue
		} else {
			hue = (#colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).hue - #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1).hue) * (value - 0.5) * 2 + #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1).hue
		}

		return UIColor(hue: hue, saturation: #colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).saturation, brightness: #colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).brightness, alpha: 1)
	}

	override func draw(_ rect: CGRect) {

		func fastFloor(_ x: CGFloat) -> CGFloat { return floor(x) }

		let thirdPath = UIBezierPath(roundedRect: CGRect(x: rect.minX + rect.width - 73, y: rect.minY + fastFloor((rect.height - 12) * 0.50000 + 0.5), width: 45, height: 12), cornerRadius: 6)
		interpolateColor(from: third).setFill()
		thirdPath.fill()

		let secondPath = UIBezierPath(roundedRect: CGRect(x: rect.minX + rect.width - 143, y: rect.minY + fastFloor((rect.height - 12) * 0.50000 + 0.5), width: 45, height: 12), cornerRadius: 6)
		interpolateColor(from: second).setFill()
		secondPath.fill()

		let firstPath = UIBezierPath(roundedRect: CGRect(x: rect.minX + rect.width - 213, y: rect.minY + fastFloor((rect.height - 12) * 0.50000 + 0.5), width: 45, height: 12), cornerRadius: 6)
		interpolateColor(from: first).setFill()
		firstPath.fill()
	}
}

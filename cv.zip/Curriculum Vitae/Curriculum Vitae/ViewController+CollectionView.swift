//
//  TableViewDecoder+CollectionView.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 26/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit
import SafariServices

extension ViewController : UICollectionViewDelegate {

	func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

		let item = collectionData[collectionView]![indexPath.row] as! Dictionary<String,String>
		let url = URL(string: item["address"]!)
		let safari = SFSafariViewController(url: url!)

		show(safari, sender: nil)
	}
}

extension ViewController : UICollectionViewDataSource {

	func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {

		return collectionData[collectionView]?.count ?? 0
	}

	func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

		let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionCellView

		let item = collectionData[collectionView]![indexPath.row] as! Dictionary<String,String>

		cell.label.text = item["name"]
		cell.image.image = UIImage(named: item["image"]!) ?? UIImage(named: "Placeholder")

		return cell
	}
}

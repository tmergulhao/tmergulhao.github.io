//
//  UIColor+Lighten.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 30/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

extension UIColor {

	func darkened (_ amount : CGFloat) -> UIColor {

		var value = brightness * (1 - amount)

		value = value > 1 ? 1 : (value < 0 ? 0 : value)

		return UIColor(hue: hue, saturation: saturation, brightness: value * amount, alpha: alpha)
	}

	func lightened (_ amount : CGFloat) -> UIColor {

		var value = brightness * (1 + amount)

		value = value > 1 ? 1 : (value < 0 ? 0 : value)

		return UIColor(hue: hue, saturation: saturation, brightness: value * amount, alpha: alpha)
	}
}

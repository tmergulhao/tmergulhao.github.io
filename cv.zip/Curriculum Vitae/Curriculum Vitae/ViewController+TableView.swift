//
//  ViewController+TableView.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 26/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit
import MapKit
import SafariServices
import MessageUI

// class ViewController : UITableViewDelegate {}

// class ViewController : UITableViewDataSource {}

extension ViewController {

	func dequeueListItem(_ tableView : UITableView, forData data : Dictionary<String,String>) -> UITableViewCell {

		let type = data["type"]!
		let content = data["content"]!

		switch type {
		case "link", "telephone", "mail":

			let cell = tableView.dequeueReusableCell(withIdentifier: "link") as! LinkCell

			cell.label?.text = content
			cell.url = URL(string: data["address"]!)
			cell.type = LinkType(rawValue: type)!

			return cell

		case "map":

			let cell = tableView.dequeueReusableCell(withIdentifier: "map") as! MapCell

			let coordinate = CLLocationCoordinate2D(latitude: -15.7543, longitude: -47.8890)
			let span = MKCoordinateSpan(latitudeDelta: 0.09, longitudeDelta: 0.09)
			let region = MKCoordinateRegion(center: coordinate, span: span)

			cell.label?.text = content
			cell.map.setRegion(region, animated: false)
			cell.isUserInteractionEnabled = false

			return cell

		default:

			let cell = UITableViewCell()

			cell.textLabel?.text = content

			return cell
		}
	}

	override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

		tableView.deselectRow(at: indexPath, animated: false)

		guard let cell = tableView.cellForRow(at: indexPath) as? LinkCell else { return }

		switch cell.type! {
		case .link:

			let safari = SFSafariViewController(url: cell.url)
			show(safari, sender: nil)

		case .mail:

			if !MFMailComposeViewController.canSendMail() { fallthrough }

			let mail = MFMailComposeViewController()

			let data = sections[indexPath.section - 1] as Dictionary<String,AnyObject>
			let items = data["items"] as! Array<Dictionary<String,String>>
			let item = items[indexPath.row - 1]

			mail.setToRecipients([item["mailAddress"]!])
			mail.setSubject("Hi! I just saw your CV app, it's very neat.")
			mail.setMessageBody("", isHTML: false)
			mail.mailComposeDelegate = self

			show(mail, sender: nil)

		case .telephone, .mail:

			UIApplication.shared.open(cell.url, options: [:], completionHandler: nil)
		}
	}

	override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat { return 48 }
	override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat { return UITableViewAutomaticDimension }

	override func numberOfSections(in tableView: UITableView) -> Int {

		guard tab != nil else { return 0 }

		return sections.count + 1
	}

	override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

		if section == 0 { return 1 }

		let data = sections[section - 1] as Dictionary<String,AnyObject>
		let type = data["type"] as! String

		switch type {
		case "paragraph": return 1
		case "titled", "collection": return 2
		case "list", "progress":
			let itemCount = (data["items"] as! Array<AnyObject>).count
			return itemCount + 1 // Header
		case "stats":
			let itemCount = (data["items"] as! Array<AnyObject>).count
			return itemCount + 2 // Header and footer
		default: break
		}

		return 0
	}

	override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

		// Header section

		if indexPath.section == 0 {

			let cell = tableView.dequeueReusableCell(withIdentifier: "title") as! TitleCell

			cell.title.text = tab["title"] as? String
			cell.subtitle.text = tab["subtitle"] as? String

			cell.isUserInteractionEnabled = false

			return cell
		}

		let data = sections[indexPath.section - 1] as Dictionary<String,AnyObject>

		let type = data["type"] as! String

		// Header row

		if indexPath.row == 0 {
			switch type {
			case "titled", "progress", "list", "collection":

				let cell = tableView.dequeueReusableCell(withIdentifier: "section") as! SectionCell

				cell.label.text = data["title"] as? String
				cell.isUserInteractionEnabled = false

				return cell
			case "stats":

				let cell = tableView.dequeueReusableCell(withIdentifier: "stats header") as! StatsHeaderView

				cell.title.text = data["title"] as? String
				cell.firstStat.text = data["first"] as? String
				cell.secondStat.text = data["second"] as? String
				cell.thridStat.text = data["third"] as? String

				cell.isUserInteractionEnabled = false

				return cell
			default: break
			}
		}

		switch type {
		case "paragraph", "titled":

			let cell = UITableViewCell()

			cell.textLabel?.text = data["content"] as? String
			cell.textLabel?.numberOfLines = 0

			cell.isUserInteractionEnabled = false

			return cell

		case "list":

			let items = data["items"] as! Array<Dictionary<String,String>>
			let item = items[indexPath.row - 1]

			return dequeueListItem(tableView, forData: item)

		case "progress":

			let items = data["items"] as! Array<Dictionary<String, AnyObject>>
			let item : Dictionary<String,AnyObject> = items[indexPath.row - 1]

			let cell = tableView.dequeueReusableCell(withIdentifier: "progress") as! ProgressCell

			cell.label.text = item["name"] as? String

			cell.value.text = item["descriptor"] as? String
			cell.progress.value = CGFloat(item["value"] as! Double)

			cell.isUserInteractionEnabled = false

			return cell
		case "stats":

			let items = data["items"] as! Array<Dictionary<String, AnyObject>>

			if indexPath.row == items.count + 1 {

				let cell = tableView.dequeueReusableCell(withIdentifier: "stats footer") as! StatsFooterView

				cell.left.text = data["lower label"] as? String
				cell.right.text = data["higher label"] as? String
				cell.isUserInteractionEnabled = false

				return cell
			}

			var item : Dictionary<String,AnyObject> = items[indexPath.row - 1]

			let cell = tableView.dequeueReusableCell(withIdentifier: "stat") as! StatCellView

			cell.label.text = item["name"] as? String

			cell.knobs.first = CGFloat(item["first"] as! Double)
			cell.knobs.second = CGFloat(item["second"] as! Double)
			cell.knobs.third = CGFloat(item["third"] as! Double)

			cell.isUserInteractionEnabled = false

			return cell
		case "collection":

			let cell = tableView.dequeueReusableCell(withIdentifier: "collection") as! CollectionCell

			collectionData[cell.collection] = (data["items"] as! [AnyObject])
			
			cell.collection.dataSource = self
			cell.collection.delegate = self
			cell.collection.reloadData()
			
			return cell
			
		default:
			return UITableViewCell()
		}
	}
}

//
//  UIColor+HSLA.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 23/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

protocol HSLA {
	var hsla : (hue : CGFloat, saturation : CGFloat, brightness : CGFloat, alpha : CGFloat) { get }
}

extension HSLA {
	var hue : CGFloat { return hsla.hue }
	var saturation : CGFloat { return hsla.saturation }
	var brightness : CGFloat { return hsla.brightness }
	var alpha : CGFloat { return hsla.alpha }
}

extension UIColor : HSLA {
	var hsla : (hue : CGFloat, saturation : CGFloat, brightness : CGFloat, alpha : CGFloat) {
		var hue : CGFloat = 0
		var saturation : CGFloat = 0
		var brightness : CGFloat = 0
		var alpha : CGFloat = 0

		getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: &alpha)

		return (hue, saturation, brightness, alpha)
	}
}

//
//  TableViewDecoder.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 24/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

class ViewController : UITableViewController {

	var tab : Dictionary<String,AnyObject>!

	var collectionData : Dictionary<UICollectionView, Array<AnyObject>> = [:]

	lazy var sections : Array<Dictionary<String,AnyObject>> = {
		return self.tab["sections"] as! Array<Dictionary<String,AnyObject>>
	}()

	override func viewDidLoad() {

		tableView.contentInset.top = 20
		tableView.contentInset.bottom = 49
		tableView.separatorColor = UIColor.clear

		let statCellViewNib = UINib(nibName: "StatCellView", bundle: nil)
		tableView.register(statCellViewNib, forCellReuseIdentifier: "stat")

		let statsHeaderViewNib = UINib(nibName: "StatsHeaderView", bundle: nil)
		tableView.register(statsHeaderViewNib, forCellReuseIdentifier: "stats header")

		let statsFooterViewNib = UINib(nibName: "StatsFooterView", bundle: nil)
		tableView.register(statsFooterViewNib, forCellReuseIdentifier: "stats footer")
	}
}

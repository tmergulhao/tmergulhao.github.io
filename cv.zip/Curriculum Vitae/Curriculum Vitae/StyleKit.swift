//
//  StyleKit.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 24/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

public class StyleKit : NSObject {

	//// Cache

	private struct Cache {
		static var imageOfProfileFill: UIImage?
		static var profileFillTargets: [AnyObject]?
		static var imageOfProfileContour: UIImage?
		static var profileContourTargets: [AnyObject]?
		static var imageOfBezierFill: UIImage?
		static var bezierFillTargets: [AnyObject]?
		static var imageOfBezierContour: UIImage?
		static var bezierContourTargets: [AnyObject]?
		static var imageOfHammerCountour: UIImage?
		static var hammerCountourTargets: [AnyObject]?
		static var imageOfHammerFill: UIImage?
		static var hammerFillTargets: [AnyObject]?
		static var imageOfSwiftContour: UIImage?
		static var swiftContourTargets: [AnyObject]?
		static var imageOfSwiftFill: UIImage?
		static var swiftFillTargets: [AnyObject]?
		static var imageOfSafari: UIImage?
		static var safariTargets: [AnyObject]?
		static var imageOfTelephone: UIImage?
		static var telephoneTargets: [AnyObject]?
		static var imageOfMail: UIImage?
		static var mailTargets: [AnyObject]?
	}

	//// Drawing Methods

	public dynamic class func drawProfileFill() {

		//// path Drawing
		let pathPath = UIBezierPath()
		pathPath.move(to: CGPoint(x: 8.64, y: 20.88))
		pathPath.addCurve(to: CGPoint(x: 9.53, y: 17.11), controlPoint1: CGPoint(x: 9.53, y: 19.67), controlPoint2: CGPoint(x: 10.13, y: 17.87))
		pathPath.addCurve(to: CGPoint(x: 9.14, y: 16.77), controlPoint1: CGPoint(x: 9.44, y: 17), controlPoint2: CGPoint(x: 9.3, y: 16.89))
		pathPath.addCurve(to: CGPoint(x: 8.34, y: 15.61), controlPoint1: CGPoint(x: 8.78, y: 16.48), controlPoint2: CGPoint(x: 8.34, y: 16.13))
		pathPath.addLine(to: CGPoint(x: 8.34, y: 13.8))
		pathPath.addCurve(to: CGPoint(x: 7.31, y: 12.3), controlPoint1: CGPoint(x: 8.05, y: 13.65), controlPoint2: CGPoint(x: 7.42, y: 13.14))
		pathPath.addCurve(to: CGPoint(x: 7.23, y: 11.55), controlPoint1: CGPoint(x: 7.26, y: 11.99), controlPoint2: CGPoint(x: 7.25, y: 11.75))
		pathPath.addCurve(to: CGPoint(x: 6.86, y: 10.64), controlPoint1: CGPoint(x: 7.19, y: 11.07), controlPoint2: CGPoint(x: 7.18, y: 10.85))
		pathPath.addCurve(to: CGPoint(x: 7.01, y: 9.58), controlPoint1: CGPoint(x: 6.42, y: 10.34), controlPoint2: CGPoint(x: 6.71, y: 9.73))
		pathPath.addCurve(to: CGPoint(x: 6.97, y: 6.78), controlPoint1: CGPoint(x: 7.2, y: 9.49), controlPoint2: CGPoint(x: 7.08, y: 8.03))
		pathPath.addCurve(to: CGPoint(x: 6.86, y: 5.22), controlPoint1: CGPoint(x: 6.91, y: 6.14), controlPoint2: CGPoint(x: 6.86, y: 5.54))
		pathPath.addCurve(to: CGPoint(x: 7.75, y: 3.26), controlPoint1: CGPoint(x: 6.86, y: 4.31), controlPoint2: CGPoint(x: 7.43, y: 3.49))
		pathPath.addCurve(to: CGPoint(x: 8.43, y: 2.67), controlPoint1: CGPoint(x: 7.98, y: 3.09), controlPoint2: CGPoint(x: 8.2, y: 2.89))
		pathPath.addCurve(to: CGPoint(x: 12.5, y: 1), controlPoint1: CGPoint(x: 9.23, y: 1.91), controlPoint2: CGPoint(x: 10.19, y: 1))
		pathPath.addCurve(to: CGPoint(x: 16.57, y: 2.67), controlPoint1: CGPoint(x: 14.81, y: 1), controlPoint2: CGPoint(x: 15.77, y: 1.91))
		pathPath.addCurve(to: CGPoint(x: 17.25, y: 3.26), controlPoint1: CGPoint(x: 16.8, y: 2.89), controlPoint2: CGPoint(x: 17.02, y: 3.09))
		pathPath.addCurve(to: CGPoint(x: 18.14, y: 5.22), controlPoint1: CGPoint(x: 17.57, y: 3.49), controlPoint2: CGPoint(x: 18.14, y: 4.31))
		pathPath.addCurve(to: CGPoint(x: 18.03, y: 6.78), controlPoint1: CGPoint(x: 18.14, y: 5.54), controlPoint2: CGPoint(x: 18.09, y: 6.14))
		pathPath.addCurve(to: CGPoint(x: 17.99, y: 9.58), controlPoint1: CGPoint(x: 17.92, y: 8.03), controlPoint2: CGPoint(x: 17.8, y: 9.49))
		pathPath.addCurve(to: CGPoint(x: 18.14, y: 10.64), controlPoint1: CGPoint(x: 18.29, y: 9.73), controlPoint2: CGPoint(x: 18.58, y: 10.34))
		pathPath.addCurve(to: CGPoint(x: 17.77, y: 11.55), controlPoint1: CGPoint(x: 17.82, y: 10.85), controlPoint2: CGPoint(x: 17.81, y: 11.07))
		pathPath.addCurve(to: CGPoint(x: 17.69, y: 12.3), controlPoint1: CGPoint(x: 17.75, y: 11.75), controlPoint2: CGPoint(x: 17.74, y: 11.99))
		pathPath.addCurve(to: CGPoint(x: 16.66, y: 13.8), controlPoint1: CGPoint(x: 17.58, y: 13.14), controlPoint2: CGPoint(x: 16.95, y: 13.65))
		pathPath.addLine(to: CGPoint(x: 16.66, y: 15.61))
		pathPath.addCurve(to: CGPoint(x: 15.86, y: 16.77), controlPoint1: CGPoint(x: 16.66, y: 16.13), controlPoint2: CGPoint(x: 16.22, y: 16.48))
		pathPath.addCurve(to: CGPoint(x: 15.47, y: 17.11), controlPoint1: CGPoint(x: 15.7, y: 16.89), controlPoint2: CGPoint(x: 15.56, y: 17))
		pathPath.addCurve(to: CGPoint(x: 16.36, y: 20.88), controlPoint1: CGPoint(x: 14.87, y: 17.87), controlPoint2: CGPoint(x: 15.47, y: 19.67))
		pathPath.addCurve(to: CGPoint(x: 18.44, y: 21.42), controlPoint1: CGPoint(x: 16.49, y: 21.05), controlPoint2: CGPoint(x: 17.33, y: 21.21))
		pathPath.addCurve(to: CGPoint(x: 23.93, y: 22.99), controlPoint1: CGPoint(x: 20.15, y: 21.75), controlPoint2: CGPoint(x: 22.49, y: 22.19))
		pathPath.addCurve(to: CGPoint(x: 24.98, y: 25.69), controlPoint1: CGPoint(x: 25.1, y: 23.64), controlPoint2: CGPoint(x: 25.02, y: 24.96))
		pathPath.addCurve(to: CGPoint(x: 24.97, y: 26), controlPoint1: CGPoint(x: 24.97, y: 25.81), controlPoint2: CGPoint(x: 24.97, y: 25.92))
		pathPath.addLine(to: CGPoint(x: 12.5, y: 26))
		pathPath.addLine(to: CGPoint(x: 0.03, y: 26))
		pathPath.addCurve(to: CGPoint(x: 0.02, y: 25.69), controlPoint1: CGPoint(x: 0.03, y: 25.92), controlPoint2: CGPoint(x: 0.03, y: 25.81))
		pathPath.addCurve(to: CGPoint(x: 1.07, y: 22.99), controlPoint1: CGPoint(x: -0.02, y: 24.96), controlPoint2: CGPoint(x: -0.1, y: 23.64))
		pathPath.addCurve(to: CGPoint(x: 6.56, y: 21.42), controlPoint1: CGPoint(x: 2.51, y: 22.19), controlPoint2: CGPoint(x: 4.85, y: 21.75))
		pathPath.addCurve(to: CGPoint(x: 8.64, y: 20.88), controlPoint1: CGPoint(x: 7.67, y: 21.21), controlPoint2: CGPoint(x: 8.51, y: 21.05))
		pathPath.close()
		UIColor.black.setFill()
		pathPath.fill()
	}

	public dynamic class func drawProfileContour() {

		//// path Drawing
		let pathPath = UIBezierPath()
		pathPath.move(to: CGPoint(x: 8.64, y: 20.88))
		pathPath.addCurve(to: CGPoint(x: 9.53, y: 17.11), controlPoint1: CGPoint(x: 9.53, y: 19.67), controlPoint2: CGPoint(x: 10.13, y: 17.87))
		pathPath.addCurve(to: CGPoint(x: 9.14, y: 16.77), controlPoint1: CGPoint(x: 9.44, y: 17), controlPoint2: CGPoint(x: 9.3, y: 16.89))
		pathPath.addCurve(to: CGPoint(x: 8.34, y: 15.61), controlPoint1: CGPoint(x: 8.78, y: 16.48), controlPoint2: CGPoint(x: 8.34, y: 16.13))
		pathPath.addLine(to: CGPoint(x: 8.34, y: 13.8))
		pathPath.addCurve(to: CGPoint(x: 7.31, y: 12.3), controlPoint1: CGPoint(x: 8.05, y: 13.65), controlPoint2: CGPoint(x: 7.42, y: 13.14))
		pathPath.addCurve(to: CGPoint(x: 7.23, y: 11.55), controlPoint1: CGPoint(x: 7.26, y: 11.99), controlPoint2: CGPoint(x: 7.25, y: 11.75))
		pathPath.addCurve(to: CGPoint(x: 6.86, y: 10.64), controlPoint1: CGPoint(x: 7.19, y: 11.07), controlPoint2: CGPoint(x: 7.18, y: 10.85))
		pathPath.addCurve(to: CGPoint(x: 7.01, y: 9.58), controlPoint1: CGPoint(x: 6.42, y: 10.34), controlPoint2: CGPoint(x: 6.71, y: 9.73))
		pathPath.addCurve(to: CGPoint(x: 6.97, y: 6.78), controlPoint1: CGPoint(x: 7.2, y: 9.49), controlPoint2: CGPoint(x: 7.08, y: 8.03))
		pathPath.addCurve(to: CGPoint(x: 6.86, y: 5.22), controlPoint1: CGPoint(x: 6.91, y: 6.14), controlPoint2: CGPoint(x: 6.86, y: 5.54))
		pathPath.addCurve(to: CGPoint(x: 7.75, y: 3.26), controlPoint1: CGPoint(x: 6.86, y: 4.31), controlPoint2: CGPoint(x: 7.43, y: 3.49))
		pathPath.addCurve(to: CGPoint(x: 8.43, y: 2.67), controlPoint1: CGPoint(x: 7.98, y: 3.09), controlPoint2: CGPoint(x: 8.2, y: 2.89))
		pathPath.addCurve(to: CGPoint(x: 12.5, y: 1), controlPoint1: CGPoint(x: 9.23, y: 1.91), controlPoint2: CGPoint(x: 10.19, y: 1))
		pathPath.addCurve(to: CGPoint(x: 16.57, y: 2.67), controlPoint1: CGPoint(x: 14.81, y: 1), controlPoint2: CGPoint(x: 15.77, y: 1.91))
		pathPath.addCurve(to: CGPoint(x: 17.25, y: 3.26), controlPoint1: CGPoint(x: 16.8, y: 2.89), controlPoint2: CGPoint(x: 17.02, y: 3.09))
		pathPath.addCurve(to: CGPoint(x: 18.14, y: 5.22), controlPoint1: CGPoint(x: 17.57, y: 3.49), controlPoint2: CGPoint(x: 18.14, y: 4.31))
		pathPath.addCurve(to: CGPoint(x: 18.03, y: 6.78), controlPoint1: CGPoint(x: 18.14, y: 5.54), controlPoint2: CGPoint(x: 18.09, y: 6.14))
		pathPath.addCurve(to: CGPoint(x: 17.99, y: 9.58), controlPoint1: CGPoint(x: 17.92, y: 8.03), controlPoint2: CGPoint(x: 17.8, y: 9.49))
		pathPath.addCurve(to: CGPoint(x: 18.14, y: 10.64), controlPoint1: CGPoint(x: 18.29, y: 9.73), controlPoint2: CGPoint(x: 18.58, y: 10.34))
		pathPath.addCurve(to: CGPoint(x: 17.77, y: 11.55), controlPoint1: CGPoint(x: 17.82, y: 10.85), controlPoint2: CGPoint(x: 17.81, y: 11.07))
		pathPath.addCurve(to: CGPoint(x: 17.69, y: 12.3), controlPoint1: CGPoint(x: 17.75, y: 11.75), controlPoint2: CGPoint(x: 17.74, y: 11.99))
		pathPath.addCurve(to: CGPoint(x: 16.66, y: 13.8), controlPoint1: CGPoint(x: 17.58, y: 13.14), controlPoint2: CGPoint(x: 16.95, y: 13.65))
		pathPath.addLine(to: CGPoint(x: 16.66, y: 15.61))
		pathPath.addCurve(to: CGPoint(x: 15.86, y: 16.77), controlPoint1: CGPoint(x: 16.66, y: 16.13), controlPoint2: CGPoint(x: 16.22, y: 16.48))
		pathPath.addCurve(to: CGPoint(x: 15.47, y: 17.11), controlPoint1: CGPoint(x: 15.7, y: 16.89), controlPoint2: CGPoint(x: 15.56, y: 17))
		pathPath.addCurve(to: CGPoint(x: 16.36, y: 20.88), controlPoint1: CGPoint(x: 14.87, y: 17.87), controlPoint2: CGPoint(x: 15.47, y: 19.67))
		pathPath.addCurve(to: CGPoint(x: 18.44, y: 21.42), controlPoint1: CGPoint(x: 16.49, y: 21.05), controlPoint2: CGPoint(x: 17.33, y: 21.21))
		pathPath.addCurve(to: CGPoint(x: 23.93, y: 22.99), controlPoint1: CGPoint(x: 20.15, y: 21.75), controlPoint2: CGPoint(x: 22.49, y: 22.19))
		pathPath.addCurve(to: CGPoint(x: 25, y: 24.5), controlPoint1: CGPoint(x: 25.1, y: 23.64), controlPoint2: CGPoint(x: 25, y: 24.42))
		pathPath.addLine(to: CGPoint(x: 12.5, y: 24.5))
		pathPath.addLine(to: CGPoint(x: 0.03, y: 24.5))
		pathPath.addCurve(to: CGPoint(x: 1.07, y: 22.99), controlPoint1: CGPoint(x: 0.03, y: 24.42), controlPoint2: CGPoint(x: -0.1, y: 23.64))
		pathPath.addCurve(to: CGPoint(x: 6.56, y: 21.42), controlPoint1: CGPoint(x: 2.51, y: 22.19), controlPoint2: CGPoint(x: 4.85, y: 21.75))
		pathPath.addCurve(to: CGPoint(x: 8.64, y: 20.88), controlPoint1: CGPoint(x: 7.67, y: 21.21), controlPoint2: CGPoint(x: 8.51, y: 21.05))
		pathPath.close()
		UIColor.black.setStroke()
		pathPath.lineWidth = 0.75
		pathPath.miterLimit = 4
		pathPath.stroke()
	}

	public dynamic class func drawBezierFill() {

		//// path Drawing
		let pathPath = UIBezierPath()
		pathPath.move(to: CGPoint(x: 12, y: 12.92))
		pathPath.addLine(to: CGPoint(x: 12, y: 13.05))
		pathPath.addCurve(to: CGPoint(x: 10, y: 15.5), controlPoint1: CGPoint(x: 10.86, y: 13.28), controlPoint2: CGPoint(x: 10, y: 14.29))
		pathPath.addCurve(to: CGPoint(x: 12.5, y: 18), controlPoint1: CGPoint(x: 10, y: 16.88), controlPoint2: CGPoint(x: 11.12, y: 18))
		pathPath.addCurve(to: CGPoint(x: 15, y: 15.5), controlPoint1: CGPoint(x: 13.88, y: 18), controlPoint2: CGPoint(x: 15, y: 16.88))
		pathPath.addCurve(to: CGPoint(x: 13, y: 13.05), controlPoint1: CGPoint(x: 15, y: 14.29), controlPoint2: CGPoint(x: 14.14, y: 13.28))
		pathPath.addCurve(to: CGPoint(x: 13, y: 0.92), controlPoint1: CGPoint(x: 13, y: 10.49), controlPoint2: CGPoint(x: 13, y: 3.46))
		pathPath.addCurve(to: CGPoint(x: 18.35, y: 10.81), controlPoint1: CGPoint(x: 14.16, y: 3.07), controlPoint2: CGPoint(x: 17.05, y: 8.41))
		pathPath.addCurve(to: CGPoint(x: 20, y: 15.5), controlPoint1: CGPoint(x: 19.38, y: 12.09), controlPoint2: CGPoint(x: 20, y: 13.72))
		pathPath.addCurve(to: CGPoint(x: 15, y: 22.57), controlPoint1: CGPoint(x: 20, y: 18.77), controlPoint2: CGPoint(x: 17.91, y: 21.54))
		pathPath.addCurve(to: CGPoint(x: 15, y: 25), controlPoint1: CGPoint(x: 15, y: 23.8), controlPoint2: CGPoint(x: 15, y: 25))
		pathPath.addLine(to: CGPoint(x: 10, y: 25))
		pathPath.addCurve(to: CGPoint(x: 10, y: 22.57), controlPoint1: CGPoint(x: 10, y: 25), controlPoint2: CGPoint(x: 10, y: 23.8))
		pathPath.addCurve(to: CGPoint(x: 5, y: 15.5), controlPoint1: CGPoint(x: 7.09, y: 21.54), controlPoint2: CGPoint(x: 5, y: 18.77))
		pathPath.addCurve(to: CGPoint(x: 6.65, y: 10.8), controlPoint1: CGPoint(x: 5, y: 13.72), controlPoint2: CGPoint(x: 5.62, y: 12.09))
		pathPath.addCurve(to: CGPoint(x: 7.9, y: 8.5), controlPoint1: CGPoint(x: 6.98, y: 10.2), controlPoint2: CGPoint(x: 7.41, y: 9.39))
		pathPath.addCurve(to: CGPoint(x: 12, y: 0.92), controlPoint1: CGPoint(x: 9.31, y: 5.9), controlPoint2: CGPoint(x: 11.13, y: 2.53))
		pathPath.addCurve(to: CGPoint(x: 12, y: 12.92), controlPoint1: CGPoint(x: 12, y: 3.41), controlPoint2: CGPoint(x: 12, y: 10.26))
		pathPath.close()
		UIColor.black.setFill()
		pathPath.fill()
	}

	public dynamic class func drawBezierContour() {

		//// path Drawing
		let pathPath = UIBezierPath()
		pathPath.move(to: CGPoint(x: 11.5, y: 13.21))
		pathPath.addCurve(to: CGPoint(x: 10, y: 15.5), controlPoint1: CGPoint(x: 10.62, y: 13.59), controlPoint2: CGPoint(x: 10, y: 14.47))
		pathPath.addCurve(to: CGPoint(x: 12.5, y: 18), controlPoint1: CGPoint(x: 10, y: 16.88), controlPoint2: CGPoint(x: 11.12, y: 18))
		pathPath.addCurve(to: CGPoint(x: 15, y: 15.5), controlPoint1: CGPoint(x: 13.88, y: 18), controlPoint2: CGPoint(x: 15, y: 16.88))
		pathPath.addCurve(to: CGPoint(x: 13.5, y: 13.21), controlPoint1: CGPoint(x: 15, y: 14.47), controlPoint2: CGPoint(x: 14.38, y: 13.59))
		pathPath.addCurve(to: CGPoint(x: 13.5, y: 1.85), controlPoint1: CGPoint(x: 13.5, y: 11.04), controlPoint2: CGPoint(x: 13.5, y: 4.94))
		pathPath.addCurve(to: CGPoint(x: 18.35, y: 10.81), controlPoint1: CGPoint(x: 14.85, y: 4.34), controlPoint2: CGPoint(x: 17.21, y: 8.7))
		pathPath.addCurve(to: CGPoint(x: 20, y: 15.5), controlPoint1: CGPoint(x: 19.38, y: 12.09), controlPoint2: CGPoint(x: 20, y: 13.72))
		pathPath.addCurve(to: CGPoint(x: 15, y: 22.57), controlPoint1: CGPoint(x: 20, y: 18.77), controlPoint2: CGPoint(x: 17.91, y: 21.54))
		pathPath.addCurve(to: CGPoint(x: 15, y: 24.5), controlPoint1: CGPoint(x: 15, y: 23.8), controlPoint2: CGPoint(x: 15, y: 24.5))
		pathPath.addLine(to: CGPoint(x: 10, y: 24.5))
		pathPath.addCurve(to: CGPoint(x: 10, y: 22.57), controlPoint1: CGPoint(x: 10, y: 24.5), controlPoint2: CGPoint(x: 10, y: 23.8))
		pathPath.addCurve(to: CGPoint(x: 5, y: 15.5), controlPoint1: CGPoint(x: 7.09, y: 21.54), controlPoint2: CGPoint(x: 5, y: 18.77))
		pathPath.addCurve(to: CGPoint(x: 6.65, y: 10.8), controlPoint1: CGPoint(x: 5, y: 13.72), controlPoint2: CGPoint(x: 5.62, y: 12.09))
		pathPath.addCurve(to: CGPoint(x: 11.5, y: 1.85), controlPoint1: CGPoint(x: 7.79, y: 8.7), controlPoint2: CGPoint(x: 10.15, y: 4.34))
		pathPath.addCurve(to: CGPoint(x: 11.5, y: 13.21), controlPoint1: CGPoint(x: 11.5, y: 4.94), controlPoint2: CGPoint(x: 11.5, y: 11.04))
		pathPath.close()
		UIColor.black.setStroke()
		pathPath.lineWidth = 0.75
		pathPath.stroke()
	}

	public dynamic class func drawHammerCountour() {

		//// head Drawing
		let headPath = UIBezierPath()
		headPath.move(to: CGPoint(x: 9.86, y: 6.03))
		headPath.addCurve(to: CGPoint(x: 1.86, y: 2.65), controlPoint1: CGPoint(x: 8.86, y: 4.58), controlPoint2: CGPoint(x: 4.11, y: 3.18))
		headPath.addLine(to: CGPoint(x: 1.32, y: 1.25))
		headPath.addCurve(to: CGPoint(x: 17.52, y: 8.29), controlPoint1: CGPoint(x: 6.01, y: 1.37), controlPoint2: CGPoint(x: 14.59, y: 4.08))
		headPath.addCurve(to: CGPoint(x: 20, y: 15.5), controlPoint1: CGPoint(x: 20.45, y: 12.51), controlPoint2: CGPoint(x: 18.9, y: 14.03))
		headPath.addCurve(to: CGPoint(x: 23.76, y: 19.14), controlPoint1: CGPoint(x: 21.09, y: 16.98), controlPoint2: CGPoint(x: 22.94, y: 17.92))
		headPath.addLine(to: CGPoint(x: 19.36, y: 22.2))
		headPath.addCurve(to: CGPoint(x: 17.6, y: 17.17), controlPoint1: CGPoint(x: 18.52, y: 20.99), controlPoint2: CGPoint(x: 18.86, y: 18.98))
		headPath.addCurve(to: CGPoint(x: 11.4, y: 17.01), controlPoint1: CGPoint(x: 16.6, y: 15.72), controlPoint2: CGPoint(x: 12.95, y: 16.53))
		headPath.addLine(to: CGPoint(x: 7.64, y: 11.59))
		headPath.addCurve(to: CGPoint(x: 9.86, y: 6.03), controlPoint1: CGPoint(x: 8.77, y: 10.51), controlPoint2: CGPoint(x: 10.86, y: 7.47))
		headPath.close()
		UIColor.black.setStroke()
		headPath.lineWidth = 0.75
		headPath.miterLimit = 4
		headPath.stroke()


		//// body Drawing
		let bodyPath = UIBezierPath()
		bodyPath.move(to: CGPoint(x: 0.5, y: 24.5))
		bodyPath.addLine(to: CGPoint(x: 10.47, y: 17.42))
		bodyPath.addLine(to: CGPoint(x: 7.04, y: 12.49))
		bodyPath.addLine(to: CGPoint(x: 0.5, y: 17.5))
		bodyPath.addLine(to: CGPoint(x: 0.5, y: 24.5))
		bodyPath.close()
		UIColor.black.setStroke()
		bodyPath.lineWidth = 0.75
		bodyPath.miterLimit = 4
		bodyPath.stroke()
	}

	public dynamic class func drawHammerFill() {

		//// head Drawing
		let headPath = UIBezierPath()
		headPath.move(to: CGPoint(x: 9.86, y: 6.03))
		headPath.addCurve(to: CGPoint(x: 1.86, y: 2.65), controlPoint1: CGPoint(x: 8.86, y: 4.58), controlPoint2: CGPoint(x: 4.11, y: 3.18))
		headPath.addLine(to: CGPoint(x: 1.32, y: 1.25))
		headPath.addCurve(to: CGPoint(x: 17.52, y: 8.29), controlPoint1: CGPoint(x: 6.01, y: 1.37), controlPoint2: CGPoint(x: 14.59, y: 4.08))
		headPath.addCurve(to: CGPoint(x: 20, y: 15.5), controlPoint1: CGPoint(x: 20.45, y: 12.51), controlPoint2: CGPoint(x: 18.9, y: 14.03))
		headPath.addCurve(to: CGPoint(x: 23.76, y: 19.14), controlPoint1: CGPoint(x: 21.09, y: 16.98), controlPoint2: CGPoint(x: 22.94, y: 17.92))
		headPath.addLine(to: CGPoint(x: 19.36, y: 22.2))
		headPath.addCurve(to: CGPoint(x: 17.6, y: 17.17), controlPoint1: CGPoint(x: 18.52, y: 20.99), controlPoint2: CGPoint(x: 18.86, y: 18.98))
		headPath.addCurve(to: CGPoint(x: 11.4, y: 17.01), controlPoint1: CGPoint(x: 16.6, y: 15.72), controlPoint2: CGPoint(x: 12.95, y: 16.53))
		headPath.addLine(to: CGPoint(x: 7.64, y: 11.59))
		headPath.addCurve(to: CGPoint(x: 9.86, y: 6.03), controlPoint1: CGPoint(x: 8.77, y: 10.51), controlPoint2: CGPoint(x: 10.86, y: 7.47))
		headPath.close()
		UIColor.black.setFill()
		headPath.fill()


		//// body Drawing
		let bodyPath = UIBezierPath()
		bodyPath.move(to: CGPoint(x: 10.47, y: 17.42))
		bodyPath.addLine(to: CGPoint(x: 7.04, y: 12.49))
		bodyPath.addLine(to: CGPoint(x: -3.19, y: 20.01))
		bodyPath.addLine(to: CGPoint(x: -0.15, y: 24.39))
		bodyPath.addLine(to: CGPoint(x: 10.47, y: 17.42))
		bodyPath.close()
		UIColor.black.setFill()
		bodyPath.fill()
	}

	public dynamic class func drawSwiftContour() {

		//// path Drawing
		let pathPath = UIBezierPath()
		pathPath.move(to: CGPoint(x: 15.4, y: 1.8))
		pathPath.addCurve(to: CGPoint(x: 22.78, y: 16.57), controlPoint1: CGPoint(x: 26.02, y: 8.34), controlPoint2: CGPoint(x: 22.78, y: 16.57))
		pathPath.addCurve(to: CGPoint(x: 24.49, y: 19.34), controlPoint1: CGPoint(x: 22.78, y: 16.57), controlPoint2: CGPoint(x: 23.92, y: 17.81))
		pathPath.addCurve(to: CGPoint(x: 24.96, y: 22.81), controlPoint1: CGPoint(x: 25.07, y: 20.88), controlPoint2: CGPoint(x: 25.06, y: 22.76))
		pathPath.addCurve(to: CGPoint(x: 21.16, y: 20.68), controlPoint1: CGPoint(x: 24.85, y: 22.86), controlPoint2: CGPoint(x: 23.51, y: 20.68))
		pathPath.addCurve(to: CGPoint(x: 13.45, y: 22.81), controlPoint1: CGPoint(x: 18.81, y: 20.68), controlPoint2: CGPoint(x: 17.62, y: 22.81))
		pathPath.addCurve(to: CGPoint(x: 0, y: 15.49), controlPoint1: CGPoint(x: 4.07, y: 22.81), controlPoint2: CGPoint(x: 0, y: 15.49))
		pathPath.addCurve(to: CGPoint(x: 8.45, y: 18.2), controlPoint1: CGPoint(x: 0, y: 15.49), controlPoint2: CGPoint(x: 4.13, y: 18.3))
		pathPath.addCurve(to: CGPoint(x: 13.97, y: 16.91), controlPoint1: CGPoint(x: 12.77, y: 18.1), controlPoint2: CGPoint(x: 13.97, y: 16.91))
		pathPath.addCurve(to: CGPoint(x: 8.71, y: 12.28), controlPoint1: CGPoint(x: 13.97, y: 16.91), controlPoint2: CGPoint(x: 12.04, y: 15.38))
		pathPath.addCurve(to: CGPoint(x: 2.25, y: 4.92), controlPoint1: CGPoint(x: 5.38, y: 9.19), controlPoint2: CGPoint(x: 2.25, y: 4.92))
		pathPath.addCurve(to: CGPoint(x: 8.88, y: 9.82), controlPoint1: CGPoint(x: 2.25, y: 4.92), controlPoint2: CGPoint(x: 7.27, y: 8.7))
		pathPath.addCurve(to: CGPoint(x: 12.1, y: 11.94), controlPoint1: CGPoint(x: 10.49, y: 10.93), controlPoint2: CGPoint(x: 12.1, y: 11.94))
		pathPath.addCurve(to: CGPoint(x: 9.44, y: 9.05), controlPoint1: CGPoint(x: 12.1, y: 11.94), controlPoint2: CGPoint(x: 10.54, y: 10.34))
		pathPath.addCurve(to: CGPoint(x: 5.53, y: 3.88), controlPoint1: CGPoint(x: 8.34, y: 7.76), controlPoint2: CGPoint(x: 5.53, y: 3.88))
		pathPath.addCurve(to: CGPoint(x: 11.8, y: 9.05), controlPoint1: CGPoint(x: 5.53, y: 3.88), controlPoint2: CGPoint(x: 9.84, y: 7.58))
		pathPath.addCurve(to: CGPoint(x: 17.51, y: 13), controlPoint1: CGPoint(x: 13.76, y: 10.52), controlPoint2: CGPoint(x: 17.51, y: 13))
		pathPath.addCurve(to: CGPoint(x: 15.4, y: 1.8), controlPoint1: CGPoint(x: 17.51, y: 13), controlPoint2: CGPoint(x: 19.77, y: 8.09))
		pathPath.close()
		UIColor.black.setStroke()
		pathPath.lineWidth = 0.75
		pathPath.miterLimit = 4
		pathPath.stroke()
	}

	public dynamic class func drawSwiftFill() {

		//// path Drawing
		let pathPath = UIBezierPath()
		pathPath.move(to: CGPoint(x: 15.4, y: 1.8))
		pathPath.addCurve(to: CGPoint(x: 22.78, y: 16.57), controlPoint1: CGPoint(x: 26.02, y: 8.34), controlPoint2: CGPoint(x: 22.78, y: 16.57))
		pathPath.addCurve(to: CGPoint(x: 24.49, y: 19.34), controlPoint1: CGPoint(x: 22.78, y: 16.57), controlPoint2: CGPoint(x: 23.92, y: 17.81))
		pathPath.addCurve(to: CGPoint(x: 24.96, y: 22.81), controlPoint1: CGPoint(x: 25.07, y: 20.88), controlPoint2: CGPoint(x: 25.06, y: 22.76))
		pathPath.addCurve(to: CGPoint(x: 21.16, y: 20.68), controlPoint1: CGPoint(x: 24.85, y: 22.86), controlPoint2: CGPoint(x: 23.51, y: 20.68))
		pathPath.addCurve(to: CGPoint(x: 13.45, y: 22.81), controlPoint1: CGPoint(x: 18.81, y: 20.68), controlPoint2: CGPoint(x: 17.62, y: 22.81))
		pathPath.addCurve(to: CGPoint(x: 0, y: 15.49), controlPoint1: CGPoint(x: 4.07, y: 22.81), controlPoint2: CGPoint(x: 0, y: 15.49))
		pathPath.addCurve(to: CGPoint(x: 8.45, y: 18.2), controlPoint1: CGPoint(x: 0, y: 15.49), controlPoint2: CGPoint(x: 4.13, y: 18.3))
		pathPath.addCurve(to: CGPoint(x: 13.97, y: 16.91), controlPoint1: CGPoint(x: 12.77, y: 18.1), controlPoint2: CGPoint(x: 13.97, y: 16.91))
		pathPath.addCurve(to: CGPoint(x: 8.71, y: 12.28), controlPoint1: CGPoint(x: 13.97, y: 16.91), controlPoint2: CGPoint(x: 12.04, y: 15.38))
		pathPath.addCurve(to: CGPoint(x: 2.25, y: 4.92), controlPoint1: CGPoint(x: 5.38, y: 9.19), controlPoint2: CGPoint(x: 2.25, y: 4.92))
		pathPath.addCurve(to: CGPoint(x: 8.88, y: 9.82), controlPoint1: CGPoint(x: 2.25, y: 4.92), controlPoint2: CGPoint(x: 7.27, y: 8.7))
		pathPath.addCurve(to: CGPoint(x: 12.1, y: 11.94), controlPoint1: CGPoint(x: 10.49, y: 10.93), controlPoint2: CGPoint(x: 12.1, y: 11.94))
		pathPath.addCurve(to: CGPoint(x: 9.44, y: 9.05), controlPoint1: CGPoint(x: 12.1, y: 11.94), controlPoint2: CGPoint(x: 10.54, y: 10.34))
		pathPath.addCurve(to: CGPoint(x: 5.53, y: 3.88), controlPoint1: CGPoint(x: 8.34, y: 7.76), controlPoint2: CGPoint(x: 5.53, y: 3.88))
		pathPath.addCurve(to: CGPoint(x: 11.8, y: 9.05), controlPoint1: CGPoint(x: 5.53, y: 3.88), controlPoint2: CGPoint(x: 9.84, y: 7.58))
		pathPath.addCurve(to: CGPoint(x: 17.51, y: 13), controlPoint1: CGPoint(x: 13.76, y: 10.52), controlPoint2: CGPoint(x: 17.51, y: 13))
		pathPath.addCurve(to: CGPoint(x: 15.4, y: 1.8), controlPoint1: CGPoint(x: 17.51, y: 13), controlPoint2: CGPoint(x: 19.77, y: 8.09))
		pathPath.close()
		UIColor.black.setFill()
		pathPath.fill()
	}

	public dynamic class func drawTicks(frame targetFrame: CGRect = CGRect(x: 0, y: 0, width: 1, height: 18), resizing: ResizingBehavior = .aspectFit) {
		//// General Declarations
		let context = UIGraphicsGetCurrentContext()!

		//// Resize to Target Frame
		context.saveGState()
		let resizedFrame: CGRect = resizing.apply(rect: CGRect(x: 0, y: 0, width: 1, height: 18), target: targetFrame)
		context.translateBy(x: resizedFrame.minX, y: resizedFrame.minY)
		context.scaleBy(x: resizedFrame.width / 1, y: resizedFrame.height / 18)


		//// lower Drawing
		let lowerPath = UIBezierPath()
		lowerPath.move(to: CGPoint(x: 0.5, y: 0))
		lowerPath.addLine(to: CGPoint(x: 0.5, y: 3))
		#colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).setStroke()
		lowerPath.lineWidth = 0.5
		lowerPath.stroke()


		//// upper Drawing
		let upperPath = UIBezierPath()
		upperPath.move(to: CGPoint(x: 0.5, y: 15))
		upperPath.addLine(to: CGPoint(x: 0.5, y: 18))
		#colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).setStroke()
		upperPath.lineWidth = 0.5
		upperPath.stroke()

		context.restoreGState()

	}

	public dynamic class func drawSafari() {
		//// General Declarations
		let context = UIGraphicsGetCurrentContext()!

		//// Oval Drawing
		let ovalPath = UIBezierPath(ovalIn: CGRect(x: 1, y: 1, width: 22, height: 22))
		#colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).setStroke()
		ovalPath.lineWidth = 1
		ovalPath.stroke()


		//// Bezier 17 Drawing
		let bezier17Path = UIBezierPath()
		bezier17Path.move(to: CGPoint(x: 5, y: 19))
		bezier17Path.addLine(to: CGPoint(x: 11, y: 11))
		bezier17Path.addLine(to: CGPoint(x: 19, y: 5))
		bezier17Path.addLine(to: CGPoint(x: 13, y: 13))
		bezier17Path.addLine(to: CGPoint(x: 5, y: 19))
		bezier17Path.close()
		#colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).setFill()
		bezier17Path.fill()


		//// Bezier 7 Drawing
		let bezier7Path = UIBezierPath()
		bezier7Path.move(to: CGPoint(x: 11.5, y: 11.5))
		bezier7Path.addLine(to: CGPoint(x: 12.5, y: 12.5))
		bezier7Path.addLine(to: CGPoint(x: 8, y: 16))
		bezier7Path.addLine(to: CGPoint(x: 11.5, y: 11.5))
		bezier7Path.close()
		#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1).setFill()
		bezier7Path.fill()


		//// Symbol Drawing
		let symbolRect = CGRect(x: 11.5, y: 3, width: 1, height: 18)
		context.saveGState()
		context.clip(to: symbolRect)
		context.translateBy(x: symbolRect.minX, y: symbolRect.minY)

		StyleKit.drawTicks(frame: CGRect(origin: .zero, size: symbolRect.size), resizing: .stretch)
		context.restoreGState()


		//// Symbol 2 Drawing
		context.saveGState()
		context.translateBy(x: 12, y: 12)
		context.rotate(by: -90 * CGFloat.pi/180)

		let symbol2Rect = CGRect(x: -0.5, y: -9, width: 1, height: 18)
		context.saveGState()
		context.clip(to: symbol2Rect)
		context.translateBy(x: symbol2Rect.minX, y: symbol2Rect.minY)

		StyleKit.drawTicks(frame: CGRect(origin: .zero, size: symbol2Rect.size), resizing: .stretch)
		context.restoreGState()

		context.restoreGState()


		//// Symbol 3 Drawing
		context.saveGState()
		context.translateBy(x: 12, y: 12)
		context.rotate(by: -22.5 * CGFloat.pi/180)

		let symbol3Rect = CGRect(x: -0.5, y: -9, width: 1, height: 18)
		context.saveGState()
		context.clip(to: symbol3Rect)
		context.translateBy(x: symbol3Rect.minX, y: symbol3Rect.minY)

		StyleKit.drawTicks(frame: CGRect(origin: .zero, size: symbol3Rect.size), resizing: .stretch)
		context.restoreGState()

		context.restoreGState()


		//// Symbol 4 Drawing
		context.saveGState()
		context.translateBy(x: 12, y: 12)
		context.rotate(by: 22.5 * CGFloat.pi/180)

		let symbol4Rect = CGRect(x: -0.5, y: -9, width: 1, height: 18)
		context.saveGState()
		context.clip(to: symbol4Rect)
		context.translateBy(x: symbol4Rect.minX, y: symbol4Rect.minY)

		StyleKit.drawTicks(frame: CGRect(origin: .zero, size: symbol4Rect.size), resizing: .stretch)
		context.restoreGState()

		context.restoreGState()


		//// Symbol 5 Drawing
		context.saveGState()
		context.translateBy(x: 12, y: 12)
		context.rotate(by: -67.5 * CGFloat.pi/180)

		let symbol5Rect = CGRect(x: -0.5, y: -9, width: 1, height: 18)
		context.saveGState()
		context.clip(to: symbol5Rect)
		context.translateBy(x: symbol5Rect.minX, y: symbol5Rect.minY)

		StyleKit.drawTicks(frame: CGRect(origin: .zero, size: symbol5Rect.size), resizing: .stretch)
		context.restoreGState()

		context.restoreGState()


		//// Symbol 6 Drawing
		context.saveGState()
		context.translateBy(x: 12, y: 12)
		context.rotate(by: -112.5 * CGFloat.pi/180)

		let symbol6Rect = CGRect(x: -0.5, y: -9, width: 1, height: 18)
		context.saveGState()
		context.clip(to: symbol6Rect)
		context.translateBy(x: symbol6Rect.minX, y: symbol6Rect.minY)

		StyleKit.drawTicks(frame: CGRect(origin: .zero, size: symbol6Rect.size), resizing: .stretch)
		context.restoreGState()

		context.restoreGState()


		//// Symbol 7 Drawing
		context.saveGState()
		context.translateBy(x: 12, y: 12)
		context.rotate(by: -45 * CGFloat.pi/180)

		let symbol7Rect = CGRect(x: -0.5, y: -9, width: 1, height: 18)
		context.saveGState()
		context.clip(to: symbol7Rect)
		context.translateBy(x: symbol7Rect.minX, y: symbol7Rect.minY)

		StyleKit.drawTicks(frame: CGRect(origin: .zero, size: symbol7Rect.size), resizing: .stretch)
		context.restoreGState()

		context.restoreGState()
	}

	public dynamic class func drawTelephone() {
		//// General Declarations
		let context = UIGraphicsGetCurrentContext()!

		//// Bezier Drawing
		context.saveGState()
		context.translateBy(x: 12.05, y: 12)
		context.rotate(by: -19.94 * CGFloat.pi/180)

		let bezierPath = UIBezierPath()
		bezierPath.move(to: CGPoint(x: -5.67, y: 3.55))
		bezierPath.addCurve(to: CGPoint(x: 7.28, y: 10.19), controlPoint1: CGPoint(x: -1.22, y: 11.35), controlPoint2: CGPoint(x: 5.76, y: 13.07))
		bezierPath.addCurve(to: CGPoint(x: 8.12, y: 6.81), controlPoint1: CGPoint(x: 8.81, y: 7.3), controlPoint2: CGPoint(x: 8.54, y: 7.53))
		bezierPath.addCurve(to: CGPoint(x: 3.13, y: 4.5), controlPoint1: CGPoint(x: 7.71, y: 6.09), controlPoint2: CGPoint(x: 4.17, y: 4.42))
		bezierPath.addCurve(to: CGPoint(x: -0.85, y: 5.63), controlPoint1: CGPoint(x: 2.09, y: 4.58), controlPoint2: CGPoint(x: 0.47, y: 6.06))
		bezierPath.addCurve(to: CGPoint(x: -4.99, y: -2.26), controlPoint1: CGPoint(x: -2.16, y: 5.2), controlPoint2: CGPoint(x: -5.52, y: -0.97))
		bezierPath.addCurve(to: CGPoint(x: -2.27, y: -4.51), controlPoint1: CGPoint(x: -4.46, y: -3.55), controlPoint2: CGPoint(x: -2.84, y: -3.66))
		bezierPath.addCurve(to: CGPoint(x: -1.74, y: -10.48), controlPoint1: CGPoint(x: -1.71, y: -5.37), controlPoint2: CGPoint(x: -1.43, y: -9.88))
		bezierPath.addCurve(to: CGPoint(x: -5.74, y: -11.49), controlPoint1: CGPoint(x: -2.05, y: -11.09), controlPoint2: CGPoint(x: -2.97, y: -11.17))
		bezierPath.addCurve(to: CGPoint(x: -5.67, y: 3.55), controlPoint1: CGPoint(x: -8.52, y: -11.81), controlPoint2: CGPoint(x: -10.12, y: -4.25))
		bezierPath.close()
		#colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).setStroke()
		bezierPath.lineWidth = 1
		bezierPath.miterLimit = 10
		bezierPath.stroke()

		context.restoreGState()
	}

	public dynamic class func drawMail() {

		//// Rectangle Drawing
		let rectanglePath = UIBezierPath(roundedRect: CGRect(x: 1, y: 5, width: 22, height: 14.5), cornerRadius: 2)
		#colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).setStroke()
		rectanglePath.lineWidth = 1
		rectanglePath.stroke()


		//// Bezier Drawing
		let bezierPath = UIBezierPath()
		bezierPath.move(to: CGPoint(x: 1.5, y: 5.5))
		bezierPath.addLine(to: CGPoint(x: 12, y: 13.5))
		bezierPath.addLine(to: CGPoint(x: 22.5, y: 5.5))
		#colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).setStroke()
		bezierPath.lineWidth = 1
		bezierPath.stroke()


		//// Bezier 3 Drawing
		let bezier3Path = UIBezierPath()
		bezier3Path.move(to: CGPoint(x: 15, y: 11))
		bezier3Path.addLine(to: CGPoint(x: 22.5, y: 18.5))
		#colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).setStroke()
		bezier3Path.lineWidth = 1
		bezier3Path.stroke()


		//// Bezier 2 Drawing
		let bezier2Path = UIBezierPath()
		bezier2Path.move(to: CGPoint(x: 9, y: 11))
		bezier2Path.addLine(to: CGPoint(x: 1.5, y: 18.5))
		#colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1).setStroke()
		bezier2Path.lineWidth = 1
		bezier2Path.stroke()
	}

	//// Generated Images

	public dynamic class var imageOfProfileFill: UIImage {
		if Cache.imageOfProfileFill != nil {
			return Cache.imageOfProfileFill!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 25, height: 25), false, 0)
		StyleKit.drawProfileFill()

		Cache.imageOfProfileFill = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfProfileFill!
	}

	public dynamic class var imageOfProfileContour: UIImage {
		if Cache.imageOfProfileContour != nil {
			return Cache.imageOfProfileContour!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 25, height: 25), false, 0)
		StyleKit.drawProfileContour()

		Cache.imageOfProfileContour = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfProfileContour!
	}

	public dynamic class var imageOfBezierFill: UIImage {
		if Cache.imageOfBezierFill != nil {
			return Cache.imageOfBezierFill!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 25, height: 25), false, 0)
		StyleKit.drawBezierFill()

		Cache.imageOfBezierFill = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfBezierFill!
	}

	public dynamic class var imageOfBezierContour: UIImage {
		if Cache.imageOfBezierContour != nil {
			return Cache.imageOfBezierContour!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 25, height: 25), false, 0)
		StyleKit.drawBezierContour()

		Cache.imageOfBezierContour = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfBezierContour!
	}

	public dynamic class var imageOfHammerCountour: UIImage {
		if Cache.imageOfHammerCountour != nil {
			return Cache.imageOfHammerCountour!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 25, height: 25), false, 0)
		StyleKit.drawHammerCountour()

		Cache.imageOfHammerCountour = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfHammerCountour!
	}

	public dynamic class var imageOfHammerFill: UIImage {
		if Cache.imageOfHammerFill != nil {
			return Cache.imageOfHammerFill!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 25, height: 25), false, 0)
		StyleKit.drawHammerFill()

		Cache.imageOfHammerFill = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfHammerFill!
	}

	public dynamic class var imageOfSwiftContour: UIImage {
		if Cache.imageOfSwiftContour != nil {
			return Cache.imageOfSwiftContour!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 25, height: 25), false, 0)
		StyleKit.drawSwiftContour()

		Cache.imageOfSwiftContour = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfSwiftContour!
	}

	public dynamic class var imageOfSwiftFill: UIImage {
		if Cache.imageOfSwiftFill != nil {
			return Cache.imageOfSwiftFill!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 25, height: 25), false, 0)
		StyleKit.drawSwiftFill()

		Cache.imageOfSwiftFill = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfSwiftFill!
	}

	public dynamic class var imageOfSafari: UIImage {
		if Cache.imageOfSafari != nil {
			return Cache.imageOfSafari!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 24, height: 24), false, 0)
		StyleKit.drawSafari()

		Cache.imageOfSafari = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfSafari!
	}

	public dynamic class var imageOfTelephone: UIImage {
		if Cache.imageOfTelephone != nil {
			return Cache.imageOfTelephone!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 24, height: 24), false, 0)
		StyleKit.drawTelephone()

		Cache.imageOfTelephone = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfTelephone!
	}

	public dynamic class var imageOfMail: UIImage {
		if Cache.imageOfMail != nil {
			return Cache.imageOfMail!
		}

		UIGraphicsBeginImageContextWithOptions(CGSize(width: 24, height: 24), false, 0)
		StyleKit.drawMail()

		Cache.imageOfMail = UIGraphicsGetImageFromCurrentImageContext()!
		UIGraphicsEndImageContext()

		return Cache.imageOfMail!
	}

	//// Customization Infrastructure

	@IBOutlet dynamic var profileFillTargets: [AnyObject]! {
		get { return Cache.profileFillTargets }
		set {
			Cache.profileFillTargets = newValue
			for target: AnyObject in newValue {
				let _ = target.perform(NSSelectorFromString("setImage:"), with: StyleKit.imageOfProfileFill)
			}
		}
	}

	@IBOutlet dynamic var profileContourTargets: [AnyObject]! {
		get { return Cache.profileContourTargets }
		set {
			Cache.profileContourTargets = newValue
			for target: AnyObject in newValue {
				let _ = target.perform(NSSelectorFromString("setImage:"), with: StyleKit.imageOfProfileContour)
			}
		}
	}

	@IBOutlet dynamic var bezierFillTargets: [AnyObject]! {
		get { return Cache.bezierFillTargets }
		set {
			Cache.bezierFillTargets = newValue
			for target: AnyObject in newValue {
				let _ = target.perform(NSSelectorFromString("setImage:"), with: StyleKit.imageOfBezierFill)
			}
		}
	}

	@IBOutlet dynamic var bezierContourTargets: [AnyObject]! {
		get { return Cache.bezierContourTargets }
		set {
			Cache.bezierContourTargets = newValue
			for target: AnyObject in newValue {
				let _ = target.perform(NSSelectorFromString("setImage:"), with: StyleKit.imageOfBezierContour)
			}
		}
	}

	@IBOutlet dynamic var hammerCountourTargets: [AnyObject]! {
		get { return Cache.hammerCountourTargets }
		set {
			Cache.hammerCountourTargets = newValue
			for target: AnyObject in newValue {
				let _ = target.perform(NSSelectorFromString("setImage:"), with: StyleKit.imageOfHammerCountour)
			}
		}
	}

	@IBOutlet dynamic var hammerFillTargets: [AnyObject]! {
		get { return Cache.hammerFillTargets }
		set {
			Cache.hammerFillTargets = newValue
			for target: AnyObject in newValue {
				let _ = target.perform(NSSelectorFromString("setImage:"), with: StyleKit.imageOfHammerFill)
			}
		}
	}

	@IBOutlet dynamic var swiftContourTargets: [AnyObject]! {
		get { return Cache.swiftContourTargets }
		set {
			Cache.swiftContourTargets = newValue
			for target: AnyObject in newValue {
				let _ = target.perform(NSSelectorFromString("setImage:"), with: StyleKit.imageOfSwiftContour)
			}
		}
	}

	@IBOutlet dynamic var swiftFillTargets: [AnyObject]! {
		get { return Cache.swiftFillTargets }
		set {
			Cache.swiftFillTargets = newValue
			for target: AnyObject in newValue {
				let _ = target.perform(NSSelectorFromString("setImage:"), with: StyleKit.imageOfSwiftFill)
			}
		}
	}

	@IBOutlet dynamic var safariTargets: [AnyObject]! {
		get { return Cache.safariTargets }
		set {
			Cache.safariTargets = newValue
			for target: AnyObject in newValue {
				let _ = target.perform(NSSelectorFromString("setImage:"), with: StyleKit.imageOfSafari)
			}
		}
	}

	@objc public enum ResizingBehavior: Int {
		case aspectFit /// The content is proportionally resized to fit into the target rectangle.
		case aspectFill /// The content is proportionally resized to completely fill the target rectangle.
		case stretch /// The content is stretched to match the entire target rectangle.
		case center /// The content is centered in the target rectangle, but it is NOT resized.

		public func apply(rect: CGRect, target: CGRect) -> CGRect {
			if rect == target || target == CGRect.zero {
				return rect
			}

			var scales = CGSize.zero
			scales.width = abs(target.width / rect.width)
			scales.height = abs(target.height / rect.height)

			switch self {
			case .aspectFit:
				scales.width = min(scales.width, scales.height)
				scales.height = scales.width
			case .aspectFill:
				scales.width = max(scales.width, scales.height)
				scales.height = scales.width
			case .stretch:
				break
			case .center:
				scales.width = 1
				scales.height = 1
			}

			var result = rect.standardized
			result.size.width *= scales.width
			result.size.height *= scales.height
			result.origin.x = target.minX + (target.width - result.width) / 2
			result.origin.y = target.minY + (target.height - result.height) / 2
			return result
		}
	}
}

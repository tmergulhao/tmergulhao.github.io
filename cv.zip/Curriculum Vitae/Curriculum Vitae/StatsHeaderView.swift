//
//  StatsHeaderView.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 23/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

class StatsHeaderView : UITableViewCell {

	@IBOutlet var title : UILabel!

	@IBOutlet var firstStat : UILabel!
	@IBOutlet var secondStat : UILabel!
	@IBOutlet var thridStat : UILabel!
}

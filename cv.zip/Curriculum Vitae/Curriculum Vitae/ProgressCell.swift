//
//  ProgressCellView.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 24/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

class ProgressCell : UITableViewCell {

	@IBOutlet var label : UILabel!
	@IBOutlet var value : UILabel!
	@IBOutlet var progress : ProgressView!
}

@IBDesignable class ProgressView : UIView {

	@IBInspectable var color : UIColor = #colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1)  { didSet { setNeedsDisplay() } }
	@IBInspectable var value : CGFloat = 0.3  { didSet { setNeedsDisplay() } }

	override func draw(_ rect: CGRect) {

		layer.cornerRadius = 6
		layer.masksToBounds = true

		let rect = CGRect(x: 0, y: 0, width: rect.width * value, height: rect.height)
		let path = UIBezierPath(roundedRect: rect, cornerRadius: 6)
		color.setFill()
		path.fill()
	}
}

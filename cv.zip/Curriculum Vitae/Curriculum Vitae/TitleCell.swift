//
//  TitleCell.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 26/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

class TitleCell : UITableViewCell {

	@IBOutlet var title : UILabel!
	@IBOutlet var subtitle : UILabel!
}

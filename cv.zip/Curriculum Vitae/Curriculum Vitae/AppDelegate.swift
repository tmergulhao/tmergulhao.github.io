//
//  AppDelegate.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 23/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

	var window: UIWindow?

	func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {

		let tabBarController = UITabBarController()

		tabBarController.tabBar.tintColor = #colorLiteral(red: 0, green: 0.8151853085, blue: 0.4869719744, alpha: 1)

		let viewController = UIStoryboard(name: "Main", bundle: nil)

		guard let path = Bundle.main.path(forResource: "Data", ofType: "plist"),
			let dictionary = NSDictionary(contentsOfFile: path) as? Dictionary<String,AnyObject>,
			let tabs = dictionary["tabs"] as? Array<Dictionary<String,AnyObject>> else {
				fatalError("Bundle.main.path(forResource: \"Data\", ofType: \"plist\")")
		}

		tabBarController.viewControllers = (0...3).map { index in

			let viewController = viewController.instantiateInitialViewController()! as! ViewController

			let tab = tabs[index]
			let name = tab["name"] as! String

			viewController.tab = tab

			viewController.tabBarItem.title = name

			switch name {
			case "Profile":
				viewController.tabBarItem.image = StyleKit.imageOfProfileContour
				viewController.tabBarItem.selectedImage = StyleKit.imageOfProfileFill
				break
			case "Design":
				viewController.tabBarItem.image = StyleKit.imageOfBezierContour
				viewController.tabBarItem.selectedImage = StyleKit.imageOfBezierFill
				break
			case "Programming":
				viewController.tabBarItem.image = StyleKit.imageOfSwiftContour
				viewController.tabBarItem.selectedImage = StyleKit.imageOfSwiftFill
				break
			case "Tools":
				viewController.tabBarItem.image = StyleKit.imageOfHammerCountour
				viewController.tabBarItem.selectedImage = StyleKit.imageOfHammerFill
				break
			default: break
			}

			return viewController
		}

		window?.rootViewController = tabBarController
		window?.addSubview(tabBarController.view)
		window?.makeKeyAndVisible()

		return true
	}
}

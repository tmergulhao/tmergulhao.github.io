//
//  MapCellView.swift
//  Curriculum Vitae
//
//  Created by Tiago Mergulhão on 24/01/17.
//  Copyright © 2017 Tiago Mergulhão. All rights reserved.
//

import UIKit
import MapKit

class MapCell : UITableViewCell {

	@IBOutlet var label : UILabel!
	@IBOutlet var map : MKMapView!

	override func awakeFromNib() {
		map.isUserInteractionEnabled = false
	}
}
